<?php
	require "process/config.php";
	require "process/process.php";

	if ( isset( $_GET['one'] ) or isset( $_GET['game'] ) or isset( $_GET['start_game'] ) )
	{
		if ( count( $_GET ) >= 1 and count( $_GET ) <= 3)
		{
			if ( count( $_GET ) == 2 )
			{
				if ( $_GET['one'] == 'auth' && $_GET['two'] == 'signup')
				{
					require "auth/signup/index.php";
				}
				else if ( $_GET['one'] == 'auth' && $_GET['two'] == 'register')
				{
					require "auth/signup/register.php";
				}
				else if ( $_GET['one'] =='games' )
				{
					$game_id = explode(':', $_GET['two']);
					if ( $game_id[0] == 'gameId')
					{
						$game_id = $game_id[1];
						require "games/register.php";
					}
				}
			}
			else if ( count( $_GET ) == 1 )
			{
				//if ( $_GET['one'] == '')
				if ( isset( $_GET['game'] ) )
				{
					require "games/index.php";
				}
				else if ( isset( $_GET['start_game'] ) )
				{
					require "games/start.php";
				}
			}
		}
	}
?>