<?php
	function DBQuery ( $conn, $type, $conds, $table, $value, $recurse )
	{
		if ( $type == 1 )
		{
			$query = mysqli_query( $conn, 'select * from '. $table .' WHERE ' . $conds);// or die(mysqli_error($conn));
			if ( mysqli_num_rows( $query ) )
			{
				return $query;
			}
			else
			{
				return AllResponses( 4, mysqli_num_rows( $query ), 0, 0, 0, 0, 0, 0 );
			}
		}
		else if ( $type == 2 )
		{
			$columns = [];
			$query = mysqli_query( $conn, 'show columns from '. $table );
			if ( $query )
			{
				while ( $x = mysqli_fetch_row($query) )
				{
					if ( $x[0] != 'id' )
						$columns[] = $x[0];
				}

				if ( count($columns) > count($conds) )
				{
					$conds[] = time();
				}

				$columns = join( ',', $columns );
				$query = mysqli_query($conn, 'insert into ' . $table . ' (' . $columns . ') values (' . join(',', $conds) . ')') or die(mysqli_error($conn)); 

				if ( $recurse == 1 )
				{
					if ( $query )
					{
						$query = DBQuery ( $conn, 1, '1 order by id DESC limit 1', $table, $value, 1 );
						if ( is_object($query) && get_class($query) == 'mysqli_result')
						{
							print AllResponses( 2, $query, ['id','username'], -1, '', $conn, [],'');
						}
					}
				}
				else
				{
					return $query;
				}
			}
			else
				return false;
		}
		else if ( $type == 3 )
		{
			$query = mysqli_query( $conn, 'select * from '. $table .' WHERE ' . $conds);// or die(mysqli_error($conn));
			return mysqli_num_rows( $query );
		}
	}

	function FilterRequest( $value )
	{
		$i = 0;
		$request = [];
		foreach ($value as $key => $value)
		{
			$request[] = '"' . $value . '"';
			// if ( $i > 0 )
			// {
				
			// }
			// $i ++;
		}
		return $request;
	}

	function mysqlVerify( $conn, $value )
	{
		if ( !empty ( $value ) )
		{
			$value = htmlentities($value);
			$m = [];
			for ( $i = 0; $i < strlen($value); $i ++ )
			{
				if ( is_numeric($value[$i]) or ctype_alpha($value[$i]) )
				{
					$m[] = $value[$i];
				}
			}

			$m = join('', $m);
			$m = '"'. $m . '"';
			return $m;
		}
		else
		{
			return 0;
		}
	}

	function AllResponses( $value, $result, $params, $tokens, $table, $conn, $cols, $title )
	{
		if ( $value == 1 )
		{
			// Response for empty input fields
			$a = array(
				'data' 		=> 	"{}",
				'status'	=>	"error",
				'message'	=>	"Input field is empty!"
			);
		}
		else if ( $value == 2 )
		{
			// Response for login queries
			if ( $params[0] == '*' )
			{
				$a = array();
				while ($x = mysqli_fetch_array( $result ) )
				{
					$b = [];
					foreach ($x as $key => $value)
					{
						if ( !is_numeric( $key ) )
						{
							$b[] = '"' . $key . '"' . "=>" . $x[$key];
						}
					}

					$b = join(',', $b);
					$b = eval("return json_encode([" . $b . "]);");
					$a[] = $b;
				}
				
				$c = array(
					"data" 		=> 	$a,
					"status" 	=> 	"success",
					"message"	=>	"Returned ". mysqli_num_rows($result) . ' result(s)'
				);

				$a = $c;
				// return json_encode($c);
			}
			else
			{
				$a = array();
				while ($x = mysqli_fetch_array( $result ) )
				{
					$b = [];
					for ($i = 0; $i < count($params); $i ++ )
					{
						$b[] = '"' . $params[$i] . '"' . "=>" . '"' . $x[$params[$i]] . '"';
					}
					
					if ( $tokens )
					{
						if ( count( $cols ) == 3 )
						{
							$game_exists = DBQuery ( $conn, 1, $cols[0] . " = " . $tokens . ' and ' . $cols[1] . ' = ' . $x[$cols[2]], $table, [], 0 );
							
							if ( is_object($game_exists) && get_class($game_exists) == 'mysqli_result' )
							{
								$r = mysqli_fetch_array( $game_exists );
								if ( $r[$cols[1]] == $x[$cols[2]] )
								{
									if ( $title[1] != '')
										$b[] = '"' . $title[1] . '"' . "=>" . 1;
									else
										$b[] = '"exists_for_user"' . "=>" . 1;
								}
								else
									if ( $title[1] != '')
										$b[] = '"' . $title[1] . '"' . "=>" . 0;
									else
										$b[] = '"exists_for_user"' . "=>" . 0;
							}
							else
							{
								if ( $title[1] != '')
										$b[] = '"' . $title[1] . '"' . "=>" . 0;
								else
									$b[] = '"exists_for_user"' . "=>" . 0;
							}
						}
					}

					$b = join(',', $b);
					$b = eval("return json_encode([" . $b . "]);");
					$a[] = $b;
				}
				
				if ( $tokens < 0 )
				{
					$c = array(
						"data" 		=> 	json_decode($a[0]),
						"status" 	=> 	"success",
						"message"	=>	"Returned ". mysqli_num_rows($result) . ' result(s)'
					);
				}
				else
				{
					$c = array(
						"data" 		=> 	[
							$title[0]	=> $a
						],
						"status" 	=> 	"success",
						"message"	=>	"Returned ". mysqli_num_rows($result) . ' result(s)'
					);
				}

				$a = $c;
			}
			// $x = mysqli_fetch_array($result);
			// $a = array(
			// 	'data' => [
			// 		'id' => $x['id'],
			// 		'username' => $x['username'],
			// 	],
			// 	"status" 	=>	"success",
			// 	'message' 	=> 	"Operation was successfull"
			// );
			
		}
		else if ( $value == 3 )
		{
			// Response for short or long user inputs
			$a = array(
				'data' 		=> 	"{}",
				'status'	=>	"error",
				'message'	=>	"Expecting a minimum of 5 characters and a maximum of 12 characters!"
			);
		}
		else if ( $value == 4 )
		{
			// Response for games that a user already applied for
			if ( !$result )
			{
				$a = array(
					'data' 		=> 	"{}",
					'status'	=>	"error",
					'message'	=>	"Request returned [0] result(s)"
				);
			}
			else
			{
				$a = array(
					'data' 		=> 	"{}",
					$title[0]		=>	[
						"live"		=>	"[]",
						"ended"		=>	"[]",
						"upcoming"	=>	"[]"
					],
					'status'	=>	"success",
					'message'	=>	"10 games found!"
				);
			}
		}
		else if ( $value == 5 )
		{
			// Response for username that already exists
			$a = array(
				'data' 		=> 	"{}",
				'status'	=>	"error",
				'message'	=>	"Username already exists!"
			);
		}
		else if ( $value == 6 )
		{
			// Response for game registration that already exists
			$a = array(
				'data' 		=> 	"{}",
				'status'	=>	"error",
				'message'	=>	"You already registered for this game!"
			);
		}
		else if ( $value == 7 )
		{
			// Response for game registration success
			$a = array(
				'data' 		=> 	[
					'username' => $result[1],
					'gameId' => $result[0],
				],
				'status'	=>	"success",
				'message'	=>	"Registration was successfull!"
			);
		}
		else if ( $value == 8 )
		{
			// Response for general server errors
			$a = array(
				'data' 		=> 	"{}",
				'status'	=>	"error",
				'message'	=>	"Unknown error occured, please try again!"
			);
		}

		return json_encode($a);
	}
?>