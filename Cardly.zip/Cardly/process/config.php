<?php
	$server = 	"localhost";
	$user 	=	'root';
	$pass	= 	'';
	$db 	=	'cardly';
	$conn = mysqli_connect($server, $user, $pass, $db);
	mysqli_select_db($conn,$db);
?>