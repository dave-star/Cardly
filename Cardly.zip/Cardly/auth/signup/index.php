
<?php
	$user = mysqlVerify($conn, $_POST['username']);
	if ( !$user )
	{
		print AllResponses( 1, 0, [], 0, 0, 0, 0, 0 );
	}
	else
	{
		if ( strlen( $user ) >= 5 and strlen( $user ) <= 12 )
		{
			$user_exists = DBQuery ( $conn, 1, "username = " . $user, 'users', $_POST, 1 );
			if ( is_object($user_exists) && get_class($user_exists) == 'mysqli_result')
			{
				print AllResponses( 2, $user_exists, ['id','username'], -1, '', $conn, [],'');
			}
		}
		else
		{
			print AllResponses( 3, 0, [], 0, 0, 0, 0, 0 );
		}
		
	}
?>