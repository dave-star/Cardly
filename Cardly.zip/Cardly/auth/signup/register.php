
<?php
	$user = mysqlVerify($conn, $_POST['username']);
	if ( !$user )
	{
		print AllResponses( 1, 0, [], 0, 0, 0, 0, 0 );
	}
	else
	{
		if ( strlen( $user ) >= 5 and strlen( $user ) <= 12 )
		{
			$user_exists = DBQuery ( $conn, 3, "username = " . $user, 'users', $_POST, 0 );
			if ( !$user_exists )
				DBQuery ( $conn, 2, FilterRequest($_POST), 'users', $_POST, 1 );
			else
				print AllResponses( 5, 0, [], 0, 0, 0, 0, 0 );
		}
		else
		{
			print AllResponses( 3, 0, [], 0, 0, 0, 0, 0 );
		}
		
	}
?>