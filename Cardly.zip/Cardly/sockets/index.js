/**
	* total users
	* cards played by each user
	* user on top
	* cards on deck
	* total point expected
	* total point received
	* time
**/
const express 	= require('express');
const http 		= require('http');
const WebSocket = require('ws');
var fs 			= require('fs');
var mysql 		= require('mysql');

const port 		= 6969
const server 	= http.createServer(express)
const wss 		= new WebSocket.Server({ server });
const TIME 		= Math.floor(new Date() / 1000)
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "cardly"
});

var GameCheck
DECK 	= 0
REQ 	= 0
USERS 	= []
P_STATE	= 0
U_PLAY 	= 0
STATE	= 0
T_TIME	= []

wss.on('connection', function connection ( ws, req ){
	ws.on('message', function incoming (data){
		details 	= data.split(',')
		ws.id 		= details[2]
		console.log(data)
		if ( ws.status != 0 )
		{
			if ( details[0] == 0 )
			{
				user_exist = 0
				for ( i = 0; i < USERS.length; i ++ )
				{
					for ( x in USERS[i] )
					{
						user = USERS[i]
						if ( x == 'gameId' )
						{
							if ( user[x] == details[5] )
							{
								ws.total	= user['total']
								ws.time		= user['time']
								ws.name 	= user['gameId']
								ws.per_card	= user['per_card']
								ws.played	= user['played']
								ws.c_time 	= Math.floor(new Date() / 1000)
								ws.play_status	= user['play_status']
							}
							user_exist = 1
							P_STATE = i
							if ( ws.play_status == 1 )
								CheckGameTime( USERS[P_STATE] )
							break
						}
					}

					if ( user_exist == 1 )
						break
				}

				if ( user_exist == 0 )
				{
					new_time = new Number(details[4])
					new_time = new_time * 60

					ws.total	= Number(details[3])
					ws.time		= new_time + TIME
					ws.name 	= Number(details[5])
					ws.per_card	= Number(details[6])
					ws.played	= 0
					ws.c_time	= Math.floor(new Date() / 1000)
					ws.play_status = 1

					USERS[REQ] = {"total" : ws.total, "time" : ws.time, "gameId" : ws.name, "per_card" : ws.per_card, "played" : ws.played, "user_top" : '', "current_time" : ws.c_time, "play_status" : 1}
					CheckGameTime( USERS[REQ] )
					DatabaseUpdates( 1, USERS[REQ] )
					REQ ++
				}

				wss.clients.forEach( function each(client){
					U_PLAY ++
				})
			}
			else
			{
				user = USERS[P_STATE]
				if ( user['user_top'] != ws.id )
				{
					if ( user['play_status'] == 1 )
					{
						ws.user_top = ws.id
						DECK += ws.per_card
						ws.played = DECK

						STATE = 1
						//SocketResponse(client)

						user['user_top'] 	= ws.id
						user['played'] 		= DECK
						user['current_time']= Math.floor(new Date() / 1000)
					}

					//console.log(user)
				}

			}
			SocketResponse( ws, USERS[P_STATE] )
		}
	})
})

function DatabaseUpdates( a, user )
{
	if ( a == 1 )
	{
		con.connect(function(err) {
			con.query("update games set upcoming = 0, live = 1 WHERE id = " + user['gameId'], function (err, result, fields) {
		    	// if (err) throw err;
		    	// console.log(result);
			});
		});
	}
	else if ( a == 2 )
	{
		con.connect(function(err) {
		  con.query("SELECT * FROM users WHERE username = '" + user['user_top'] + "'", function (err, result) {
			    if (err) throw err;
			    //console.log(result[0].username);
			    con.query("update games set user_top = " + result[0].id + ", upcoming = 0, live = 0, ended = 1 WHERE id = " + user['gameId'], function (err, result, fields) {
			    	// if (err) throw err;
			    	// console.log(result);
				});
		  });
		});
	}
}

function CheckGameTime( user )
{
	c_time 	= Math.floor(new Date() / 1000)
	m_time	= user['time']

	if ( c_time < m_time && user['total'] >= user['played'])
	{
		// console.log(c_time)
		// console.log(m_time)
		GameCheck = setTimeout(function(){ CheckGameTime(USERS[P_STATE]); }, 2000);
	}
	else
	{
		//console.log("Time elapsed")
		DatabaseUpdates( 2, user )
		T_TIME.splice(T_TIME.length - 1, T_TIME.length, user['name'])
		user['play_status'] = 0
		user['time'] = c_time
		clearTimeout(GameCheck)
	}
}

function SocketResponse ( ws, user )
{
	//console.log(user['play_status'])
	if ( user['play_status'] == 1 )
		state = 0
	else
		state = 1

	if ( state == 0 )
	{
		ws.on('message', function incoming (data){
			wss.clients.forEach( function each(client){
				if ( client != ws && client.readyState == WebSocket.OPEN ){
					client.send(JSON.stringify(user))
					//console.log(ws.id)
				}
				else
				{
					client.send('{"status" : "success", "messsage" : "Card on deck, you can only play after others have played!"}')
				}
			})
		})
	}
	else
	{
		window.clearTimeout(GameCheck)
		clearTimeout(GameCheck)
		ws.on('message', function incoming (data){
			wss.clients.forEach( function each(client){
				if ( client != ws && client.readyState == WebSocket.OPEN ){
					// if ( user['user_top'] == ws.id)
					// 	client.send('{"status" : "success", "messsage" : "YOU WIN"}')
					// else
					// 	client.send('{"status" : "error", "messsage" : "YOU LOSE"}')
				}
				else
				{
					if ( user['user_top'] == ws.id)
						client.send('{"status" : "success", "messsage" : "YOU WIN"}')
					else
						client.send('{"status" : "error", "messsage" : "YOU LOSE"}')
				}
			})
		})
	}
}

server.listen( port , function () {
	console.log(`Server is listening... on ${port}`)
})
