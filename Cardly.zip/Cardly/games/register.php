<?php
	$headers = apache_request_headers();
	if ( isset( $headers['Authorization'] ) )
	{
		$token = explode(' ',$headers['Authorization']);
		$token = $token[1];

		$user_exists = DBQuery ( $conn, 3, "id = " . $token, 'users', [$headers['Authorization']], 0 );

		if ( $user_exists )
		{
			$reg_details = DBQuery ( $conn, 3, "game_id = " . $game_id . ' and user_id = ' . $token, 'my_games', [$headers['Authorization']], 0 );
			
			if ( $reg_details )
				print AllResponses( 6, 0, [], 0, 0, 0, 0, 0 );
			else
			{
				$register = DBQuery ( $conn, 2, [$game_id,$token], 'my_games', [$headers['Authorization']], 0 );
				if ( $register )
				{
					$username = DBQuery ( $conn, 1, "id = " . $token, 'users', [$headers['Authorization']], 0 );
					$x = mysqli_fetch_array($username);
					print AllResponses( 7, [$game_id,$x['username']], [], 0, 0, 0, 0, 0 );
				}
				else
				{
					print AllResponses( 8, 0, [], 0, 0, 0, 0, 0 );
				}
			}
		}
		else
		{
			print AllResponses( 4, 0, [], 0, 0, 0, 0, 0 );
		}
	}
?>