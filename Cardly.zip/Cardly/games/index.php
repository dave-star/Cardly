<?php
	$headers = apache_request_headers();
	if ( isset( $headers['Authorization'] ) )
	{
		$token = explode(' ',$headers['Authorization']);
		$token = $token[1];
		
		$user_exists = DBQuery ( $conn, 3, "id = " . $token, 'users', [$headers['Authorization']], 0 );

		if ( $user_exists )
		{
			$games = DBQuery ( $conn, 1, "1", 'games', [$headers['Authorization']], 0 );
			if ( is_object( $games ) && get_class( $games ) == 'mysqli_result' )
				
				print AllResponses( 2, $games, ['live','ended','upcoming'], $token, 'my_games', $conn, ['user_id', 'game_id', 'id'], ['games','exists_for_user']);

			else
				print $games;
		}
		else
		{
			print AllResponses( 1, 0, [], 0, 0, 0, 0, 0 );
		}
	}

?>


